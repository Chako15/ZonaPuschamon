# ZonaPuschamon

Plantilla Vite + React + Tailwind para tu sitio estilo *SAO* (futurista).
Incluye animaciones, búsqueda, y un formulario para agregar entradas con enlaces.

## Cómo usar (rápido)
1. Descargar y descomprimir el ZIP.
2. En la carpeta del proyecto, correr:
   ```bash
   npm install
   npm run dev
   ```
3. Crear un repo en GitHub y subir la carpeta.
4. Conectar el repo a Vercel y desplegar (Vercel detecta Vite/React automáticamente).

## Notas
- Respeta derechos de autor: enlaza solo a contenido propio o con permiso.
- El contenido se guarda en `localStorage` del navegador para que pruebes rápido.
